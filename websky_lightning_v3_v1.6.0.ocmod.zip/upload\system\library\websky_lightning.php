<?php
class WebskyLightning {
    private static $captureFile = '';
    public static function serve($registry) {
        if (!self::catalogRequest() || !self::eligible($registry)) { return; }
        $config = $registry->get('config');
        if (!$config->get('module_websky_lightning_status') || !$config->get('module_websky_lightning_page_cache')) { return; }
        $file = self::cacheFile($registry);
        $ttl = (int)$config->get('module_websky_lightning_cache_ttl');
        if ($ttl < 60) { $ttl = 900; }
        if (is_file($file) && filemtime($file) >= time() - $ttl) {
            self::record('hit');
            $content = @file_get_contents($file);
            if (!is_string($content)) { return; }
            $acceptsGzip = !empty($_SERVER['HTTP_ACCEPT_ENCODING']) && strpos($_SERVER['HTTP_ACCEPT_ENCODING'], 'gzip') !== false;
            $useGzip = $acceptsGzip && function_exists('gzencode') && !ini_get('zlib.output_compression');
            if (!headers_sent()) {
                header('X-Websky-Cache: HIT');
                header('X-Websky-Cache-Age: ' . (time() - filemtime($file)));
                header('Vary: Accept, Accept-Encoding', false);
                if ($useGzip) { header('Content-Encoding: gzip'); }
            }
            echo $useGzip ? gzencode($content, 6) : $content;
            exit;
        }
        self::record('miss');
        if (!headers_sent()) { header('X-Websky-Cache: MISS'); header('Vary: Accept, Accept-Encoding', false); }
        self::$captureFile = $file;
        ob_start(array(__CLASS__, 'capture'));
    }

    public static function capture($output) {
        $content = $output;
        if (strlen($content) > 2 && substr($content, 0, 2) === "\x1f\x8b" && function_exists('gzdecode')) {
            $decoded = @gzdecode($content);
            if (is_string($decoded)) { $content = $decoded; }
        }
        if (self::$captureFile && strlen($content) >= 500 && stripos($content, '<html') !== false) {
            $dir = dirname(self::$captureFile);
            if ((is_dir($dir) || @mkdir($dir, 0755, true)) && is_writable($dir)) {
                $tmp = self::$captureFile . '.' . getmypid() . '.tmp';
                if (@file_put_contents($tmp, $content, LOCK_EX) !== false) { @rename($tmp, self::$captureFile); } else { @unlink($tmp); }
            }
        }
        return $output;
    }

    public static function webp($file) {
        if (!function_exists('imagewebp') || !is_file($file)) { return $file; }
        $extension = strtolower(pathinfo($file, PATHINFO_EXTENSION));
        if (!in_array($extension, array('jpg', 'jpeg', 'png'))) { return $file; }
        $webp = preg_replace('/\.(jpe?g|png)$/i', '.webp', $file);
        if (is_file($webp) && filemtime($webp) >= filemtime($file)) { return $webp; }
        $image = $extension === 'png' ? @imagecreatefrompng($file) : @imagecreatefromjpeg($file);
        if (!$image) { return $file; }
        if ($extension === 'png') { imagepalettetotruecolor($image); imagealphablending($image, true); imagesavealpha($image, true); }
        $ok = @imagewebp($image, $webp, 82); imagedestroy($image);
        return $ok && is_file($webp) ? $webp : $file;
    }

    public static function cacheDirectory() {
        $storage = defined('DIR_STORAGE') ? DIR_STORAGE : dirname(rtrim(DIR_CACHE, '/\\')) . DIRECTORY_SEPARATOR;
        $dir = rtrim($storage, '/\\') . DIRECTORY_SEPARATOR . 'websky_lightning_cache' . DIRECTORY_SEPARATOR;
        if (!is_dir($dir)) { @mkdir($dir, 0755, true); }

        $legacy = rtrim(DIR_CACHE, '/\\') . DIRECTORY_SEPARATOR . 'websky_lightning' . DIRECTORY_SEPARATOR;
        if (is_dir($legacy) && is_dir($dir)) {
            foreach (glob($legacy . '*') ?: array() as $file) {
                if (!is_file($file)) { continue; }
                $target = $dir . basename($file);
                if (!is_file($target)) { @rename($file, $target) || @copy($file, $target); }
            }
        }
        return $dir;
    }

    public static function databaseQuery($adaptor, $sql) {
        $trimmed = ltrim((string)$sql);
        if (preg_match('/^(INSERT|UPDATE|DELETE|REPLACE|TRUNCATE|ALTER|CREATE|DROP|RENAME)\b/i', $trimmed)) {
            $result = $adaptor->query($sql);
            self::invalidateDatabaseCache();
            return $result;
        }

        if (!defined('WEBSKY_LIGHTNING_QUERY_CACHE') || !WEBSKY_LIGHTNING_QUERY_CACHE || !self::cacheableDatabaseQuery($trimmed)) {
            return $adaptor->query($sql);
        }

        $dir = self::databaseCacheDirectory();
        $generation = self::databaseCacheGeneration($dir);
        $file = $dir . hash('sha256', $generation . '|' . $trimmed) . '.qcache';
        $ttl = 300;
        if (is_file($file) && filemtime($file) >= time() - $ttl) {
            $cached = @unserialize((string)@file_get_contents($file));
            if (is_array($cached) && isset($cached['rows'], $cached['num_rows'])) {
                self::recordDatabaseCache('hit');
                $query = new \stdClass();
                $query->row = isset($cached['row']) ? $cached['row'] : array();
                $query->rows = $cached['rows'];
                $query->num_rows = (int)$cached['num_rows'];
                return $query;
            }
        }

        self::recordDatabaseCache('miss');
        $query = $adaptor->query($sql);
        if (is_object($query) && isset($query->rows, $query->num_rows)) {
            $payload = serialize(array('row' => isset($query->row) ? $query->row : array(), 'rows' => $query->rows, 'num_rows' => (int)$query->num_rows));
            $tmp = $file . '.' . getmypid() . '.tmp';
            if (@file_put_contents($tmp, $payload, LOCK_EX) !== false) { @rename($tmp, $file); } else { @unlink($tmp); }
        }
        if (mt_rand(1, 200) === 1) { self::pruneDatabaseCache($dir); }
        return $query;
    }

    public static function invalidateDatabaseCache() {
        $dir = self::databaseCacheDirectory();
        $file = $dir . 'generation';
        $handle = @fopen($file, 'c+');
        if (!$handle) { return; }
        if (@flock($handle, LOCK_EX)) {
            $value = (int)trim((string)stream_get_contents($handle));
            ftruncate($handle, 0); rewind($handle); fwrite($handle, (string)($value + 1)); fflush($handle); flock($handle, LOCK_UN);
        }
        fclose($handle);
    }

    private static function cacheableDatabaseQuery($sql) {
        if (!preg_match('/^(SELECT|SHOW|DESCRIBE|DESC|EXPLAIN)\b/i', $sql)) { return false; }
        if (preg_match('/\b(FOR\s+UPDATE|LOCK\s+IN\s+SHARE|INTO\s+OUTFILE|SQL_NO_CACHE|SQL_CALC_FOUND_ROWS)\b/i', $sql)) { return false; }
        if (preg_match('/\b(RAND|NOW|CURDATE|CURTIME|CURRENT_TIMESTAMP|UNIX_TIMESTAMP|LAST_INSERT_ID|FOUND_ROWS|CONNECTION_ID|UUID)\s*\(/i', $sql)) { return false; }
        return true;
    }

    private static function databaseCacheDirectory() {
        $storage = defined('DIR_STORAGE') ? DIR_STORAGE : dirname(rtrim(DIR_CACHE, '/\\')) . DIRECTORY_SEPARATOR;
        $dir = rtrim($storage, '/\\') . DIRECTORY_SEPARATOR . 'websky_lightning_db_cache' . DIRECTORY_SEPARATOR;
        if (!is_dir($dir)) { @mkdir($dir, 0755, true); }
        return $dir;
    }

    private static function databaseCacheGeneration($dir) {
        $file = $dir . 'generation';
        if (!is_file($file)) { @file_put_contents($file, '1', LOCK_EX); }
        return max(1, (int)trim((string)@file_get_contents($file)));
    }

    private static function recordDatabaseCache($type) {
        $file = self::databaseCacheDirectory() . 'stats.json';
        $handle = @fopen($file, 'c+');
        if (!$handle) { return; }
        if (@flock($handle, LOCK_EX)) {
            $stats = json_decode((string)stream_get_contents($handle), true);
            if (!is_array($stats)) { $stats = array('hit' => 0, 'miss' => 0); }
            $stats[$type] = isset($stats[$type]) ? (int)$stats[$type] + 1 : 1;
            $stats['updated'] = time();
            ftruncate($handle, 0); rewind($handle); fwrite($handle, json_encode($stats)); fflush($handle); flock($handle, LOCK_UN);
        }
        fclose($handle);
    }

    private static function pruneDatabaseCache($dir) {
        foreach (glob($dir . '*.qcache') ?: array() as $file) { if (is_file($file) && filemtime($file) < time() - 86400) { @unlink($file); } }
    }

    private static function eligible($registry) {
        $request = $registry->get('request');
        $session = $registry->get('session');
        if (!$request || !isset($request->server['REQUEST_METHOD']) || strtoupper($request->server['REQUEST_METHOD']) !== 'GET') { return false; }
        if (isset($request->get['websky_bypass'])) { return false; }
        if (!empty($request->server['HTTP_X_REQUESTED_WITH'])) { return false; }
        if ($session && (!empty($session->data['customer_id']) || !empty($session->data['customer']) || !empty($session->data['cart']) || !empty($session->data['guest']))) { return false; }
        $route = isset($request->get['route']) ? $request->get['route'] : 'common/home';
        $allowed = array('common/home', 'product/product', 'product/category', 'product/manufacturer/info', 'information/information');
        return in_array($route, $allowed, true);
    }

    private static function cacheFile($registry) {
        $request = $registry->get('request'); $session = $registry->get('session'); $config = $registry->get('config');
        $uri = isset($request->server['REQUEST_URI']) ? $request->server['REQUEST_URI'] : '/';
        $language = $session && isset($session->data['language']) ? $session->data['language'] : $config->get('config_language');
        $currency = $session && isset($session->data['currency']) ? $session->data['currency'] : $config->get('config_currency');
        $acceptsWebp = !empty($request->server['HTTP_ACCEPT']) && strpos($request->server['HTTP_ACCEPT'], 'image/webp') !== false ? 'webp' : 'legacy';
        $key = (int)$config->get('config_store_id') . '|' . $language . '|' . $currency . '|' . $acceptsWebp . '|' . $uri;
        return self::cacheDirectory() . hash('sha256', $key) . '.html';
    }

    private static function catalogRequest() {
        return defined('DIR_APPLICATION') && strtolower(basename(rtrim(DIR_APPLICATION, '/\\'))) === 'catalog';
    }

    private static function record($type) {
        $file = self::cacheDirectory() . 'stats.json';
        $handle = @fopen($file, 'c+');
        if (!$handle) { return; }
        if (@flock($handle, LOCK_EX)) {
            $raw = stream_get_contents($handle);
            $stats = json_decode((string)$raw, true);
            if (!is_array($stats)) { $stats = array('hit' => 0, 'miss' => 0); }
            $stats[$type] = isset($stats[$type]) ? (int)$stats[$type] + 1 : 1;
            $stats['updated'] = time();
            ftruncate($handle, 0); rewind($handle); fwrite($handle, json_encode($stats)); fflush($handle); flock($handle, LOCK_UN);
        }
        fclose($handle);
    }
}
